# Anthropic 开发体系研究与跨项目适配

研究日期：2026-09-11。原文核对截至 `2026-09-11T17:28:30Z`。作者：本次开发体系研究 Agent。本文是研究与适配建议，不能充当产品实现、生产验收或所有宿主自动加载的证据。

研究结论：可跨项目复用的是“明确目标、读取当前事实、按风险执行、依靠结果验证、保留接续证据、用评测改进”的工作方法。具体目录、命令、身份、流程引擎、审批和运行时要绑定各项目现状。通用 Skill 应提供这一方法与适配步骤，不能把 某一项目的任务状态、技术候选或业务权限写成所有项目的默认值。

## 研究范围与可信度

从用户提供的 Datawhale 文章追溯两篇原文，再沿 [Anthropic Engineering 官方目录](https://www.anthropic.com/engineering)和正文链接核对互补材料。覆盖 16 篇官方文章或官方介绍页，包含有效 Agent、工具、上下文、长期 Harness、评测、Skills、多 Agent、安全隔离、身份及 SDLC；不以转载、搜索排名或社区提示词作为技术结论依据。这是围绕开发体系的系统性检索，不声称穷尽该公司全网内容。

用户文章中的“约 80% 合入代码由 Claude 编写”和“工程师代码产量约 8 倍”可追溯到 Jason Clinton 的内部实践介绍，属于厂商自报，不是本项目的效率或质量承诺。[内部 SDLC 安全实践](https://claude.com/blog/how-anthropic-secures-its-ai-native-software-development-lifecycle)

以下把**原文事实**与**本次适配推导**分开。网页的发布日期不等于内容从未更新；模型版本、API、许可、价格和宿主能力在实际采用时仍需重新核对。机器可读目录见 [sources.json](sources.json)。

## 一手来源与适用边界

| ID | 文章及发布日期 | 原文事实摘要 | 采用边界 |
|---|---|---|---|
| S01 | [Building effective agents](https://www.anthropic.com/engineering/building-effective-agents)，2024-12-19 | 区分固定工作流与动态 Agent；只在效果需要时增加复杂度。 | 原文已提示工具生态变化；不把“直接 API”解释成必须重写成熟运行时。 |
| S02 | [How we built our multi-agent research system](https://www.anthropic.com/engineering/multi-agent-research-system)，2025-06-13 | 多 Agent 适合独立、广度优先研究；委派须有目标、输出和边界。 | 文中多 Agent 约消耗聊天 15 倍 token；多数编码任务可并行部分更少。 |
| S03 | [Writing effective tools for agents — with agents](https://www.anthropic.com/engineering/writing-tools-for-agents)，2025-09-11 | 工具职责、参数、错误反馈和结果裁剪影响任务成功；留出测试集防过拟合。 | 不把每个 API 都包装成工具；评估允许多种正确实现路径。 |
| S04 | [Effective context engineering for AI agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)，2025-09-29 | 按需读取高信号上下文，使用引用、压缩与结构化笔记维持长期任务。 | 最少不等于不足；压缩可能丢失约束，运行时检索也有延迟。 |
| S05 | [Equipping agents for the real world with Agent Skills](https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills)，2025-10-16；开放标准更新 2025-12-18 | Skill 采用元数据、正文、按需资源逐层加载；从真实能力缺口与评测开始。 | 格式可移植不代表权限和工具通用；外部脚本、依赖和网络行为需审查。 |
| S06 | [Beyond permission prompts: making Claude Code more secure and autonomous](https://www.anthropic.com/engineering/claude-code-sandboxing)，2025-10-20 | 文件系统与网络隔离共同约束执行范围，减少逐动作审批。 | 这是特定产品实现；不能用提示词或命令关键词匹配替代隔离。 |
| S07 | [Effective harnesses for long-running agents](https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents)，2025-11-26 | 首次初始化与后续增量执行分开；功能清单、交接、真实浏览器检查减少过早完成。 | 实验针对全栈 Web；两个角色使用同一 Harness，不等于必须搭两套执行引擎。 |
| S08 | [Demystifying evals for AI agents](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents)，2026-01-09 | 评估最终环境状态；结合确定性、模型与人工判断；隔离 trial 并读取轨迹。 | 一次通过不是稳定性；评测器也会错，不能仅追求分数。 |
| S09 | [Quantifying infrastructure noise in agentic coding evals](https://www.anthropic.com/engineering/infrastructure-noise)，2026-02-05 | 同模型、同任务可因资源配置产生分数差异；需记录资源与执行约束。 | 文中 Terminal-Bench 极端配置相差 6 个百分点，不能外推成固定修正值。 |
| S10 | [Harness design for long-running application development](https://www.anthropic.com/engineering/harness-design-long-running-apps)，2026-03-24 | 分离生成与评估可发现自评遗漏；新模型后逐项移除不再有效的脚手架。 | 游戏示例为 20 分钟/$9 对 6 小时/$200；仍有漏测，非全面生产能力证明。 |
| S11 | [How we built Claude Code auto mode](https://www.anthropic.com/engineering/claude-code-auto-mode)，2026-03-25 | 动作审批分类器减少打断，但有误放；委派和返回也需检查。 | 属于概率防御。其默认授权判定不覆盖当前宿主或用户的明确指令。 |
| S12 | [Scaling Managed Agents: Decoupling the brain from the hands](https://www.anthropic.com/engineering/managed-agents)，2026-04-08 | 将持久会话、Harness 与执行环境解耦，支持失败恢复，并使凭据远离执行沙箱。 | 是托管服务设计经验；不因此要求所有项目购买该服务或自造元 Harness。 |
| S13 | [How we contain Claude across products](https://www.anthropic.com/engineering/how-we-contain-claude)，2026-05-25 | 环境隔离、模型防御与外部内容检查互补；允许域名也可能承载攻击者账号。 | 沙箱内仍可能损坏工作区；连接器可信不等于其数据可信，子 Agent 输出也不自动可信。 |
| S14 | [Zero Trust for AI agents](https://claude.com/blog/zero-trust-for-ai-agents)，2026-05-27 | 官方介绍强调身份、逐任务权限、记忆投毒防护与按成熟度采用。 | 已读介绍页；链接 PDF 返回不可重试读取错误，未核对全文及其合规映射。 |
| S15 | [How Anthropic secures its AI-native software development lifecycle](https://claude.com/blog/how-anthropic-secures-its-ai-native-software-development-lifecycle)，2026-07-21 | 风险分层、观察模式、抽样审查和单用途身份配合；事故诊断者无直接发布权限。 | 内部实践依赖其身份、CI、监控与人员责任；不能只复制文档便宣称等效。 |
| S16 | [The AI-Native SDLC playbook](https://claude.com/blog/the-ai-native-sdlc-playbook)，2026-08-21 | 六阶段由可追溯产物衔接；实践按依赖采用；明确每类产物的权威系统。 | 原文采用 Git/Claude 例子，也允许接入现有系统；不得机械新增三份文档和逐步确认。 |

## 交叉核对后需要修正的理解

1. **持续应用应带有删除规则。** S07 的长期交接有效；S10、S12 又说明模型能力变化后，固定重置、冲刺或额外角色可能成为负担。本次推导：每条流程机制都要能说明解决哪个已观察失败，升级时在同条件下逐项比较，保留有效机制。当前用户要求保留的安全与权限规则不属于可通过评测随意删除的对象。
2. **计划与人类责任不等于每一步询问。** S16 描述分阶段的人类决定；S06、S11 又专门解决审批疲劳。本次推导：先承接当前已授权目标，准备可审查产物；局部可逆工作继续执行，只有目标重大冲突或实际授权边界变化才需要相应决定。
3. **多角色不保证评审独立。** S02 证明独立研究方向可以获益；S10 承认评审模型仍会宽松打分；S13 指出返回结果可形成信任升级。本次推导：评审直接查看代码、工具结果与运行状态；记录实际执行者，不把同一个模型换个角色名写成独立保证。
4. **测试要防作假，也要容许修正测试缺陷。** S16 的禁止弱化测试示例与 S08、S03 的评测器校准需要同时理解。本次推导：不得删失败断言换绿灯；如果需求或测试本身错误，先保留复现与契约依据，再审查修改测试的理由和差异，补能证明修正正确的独立案例。
5. **可移植的 Skill 不是跨宿主权限系统。** S05 支持资源包移植；S06、S12、S13 把执行边界放在环境中。本次推导：Skill 负责流程与能力发现，实际宿主负责工具和权限；文档、hook、CI 配置、已运行门禁、基础设施隔离分开声明。

## 应纳入通用 Skill 的 12 项采用建议

下表均为本次跨项目工程适配，不是 Anthropic 原文中的统一强制规范。列出的来源支持设计动机；落地后还须以当前项目实测证明有效。

| 建议 | 具体执行方式 | 如何证明持续应用 | 依据 |
|---|---|---|---|
| 1. 先识别项目 | 解析实际 cwd、项目标识、当前用户目标、现有任务入口和允许路径；不能按相邻仓名称猜测。 | 错目录、未知项目、非 Git 目录案例均不串入旧规则。 | S04、S07 |
| 2. 通用方法与项目适配分层 | 通用 Skill 保存决策规则；项目提供入口、权威状态、命令与业务约束；无适配时先只读探测。 | 在不同语言及纯文档项目验证入口，记录未支持宿主。 | S05、S16 |
| 3. 复用一个权威记录 | intent/spec/plan 用已有字段或引用表达；复杂任务才维护依赖节点。 | 新工作不重用已完成任务授权，不生成第二产品看板。 | S16 |
| 4. 以风险选择验证深度 | 低风险局部编辑做针对性检查；权限、状态、数据、外部作用选择相应负例。 | 把风险、验收和命令关联，无法运行的检查标记 NOT_RUN。 | S01、S08 |
| 5. 先打通反馈再扩大自治 | 确认测试命令确实执行、能失败并反馈具体原因，再扩写代码。 | 通过案例之外必须包含预期失败案例；禁止空集通过。 | S03、S08 |
| 6. 验收以真实结果为准 | 按任务检查文件、进程版本、接口、持久状态和用户操作；产物哈希绑定时间与范围。 | 源码有实现、截图、模型自述分别不能替代运行验收。 | S07、S08 |
| 7. 工具少而清晰 | 描述前置、参数、输出、副作用、失败与恢复；优先定位后读，返回可继续定位的证据。 | 错参数、截断、权限拒绝能返回可行动信息，且不泄露秘密。 | S03 |
| 8. 交接保留证据引用 | 保存当前目标、完成/未完成、下一节点、失败及产物引用；恢复时核对当前文件。 | 在新会话或独立进程中能从记录接续，不重复外部作用。 | S04、S07、S12 |
| 9. 有条件使用并行与评审 | 仅按当前授权委派；限定依赖、写范围和输出；按缺陷收益与集成成本调整。 | 真正独立检查原始产物；共享写面不并行，记录遗漏和返工。 | S02、S10 |
| 10. 把行为评测与工具回归分开 | Skill/模型/hook 变化选择真实场景，固定输入、版本、权限与资源；观察行为及最终状态。 | 工具测试通过不冒充模型回放；多次 trial 的失败均保留。 | S08、S09 |
| 11. 在实际边界内自治 | 使用宿主已有身份、沙箱和授权；外部内容只作数据；委派不能扩大原主体权限。 | 文档要求与实际隔离状态分别记录；新审查者先观察，不自动升权。 | S06、S11、S13—S15 |
| 12. 用事故与成本改进体系 | 真实失败补成回归，按返工/逃逸缺陷/时延与费用决定保留或移除机制；按授权启用候选。 | 更新含版本、原因、验证与恢复路径；没有数据时不编造收益。 | S03、S08—S10、S15 |


## 研究边界

本文件为2026-09-11已核对研究的通用快照，供Skill按需读取。覆盖15篇正文和1个官方介绍页；Zero Trust PDF读取失败未计作全文。它不依赖任何项目目录，不证明工具/生产接入或收益。后续涉及版本、权限、API等不稳定事实时重新核对原文。
