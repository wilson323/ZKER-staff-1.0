# 一手来源与适用边界

检索核对：2026-09-11。以下17项是可读的一手文章、官方文档和仓库；不声称穷尽公司全部出版物。动态文档按访问日期使用。Skill中的模板、项目映射与脚本是本地工程适配，不是厂商原件或效果保证。

| ID | 来源与发布日期 | 支撑与限制 |
|---|---|---|
| S01 | [The AI-Native SDLC playbook](https://claude.com/blog/the-ai-native-sdlc-playbook)，2026-08-21 | 六阶段产物链与现有权威系统共存；不要求所有组织替换工单系统 |
| S02 | [How Anthropic secures its AI-native SDLC](https://claude.com/blog/how-anthropic-secures-its-ai-native-software-development-lifecycle)，Jason Clinton，2026-07-21 | 身份、风险分层、审查观察和代理调用边界；80%与8倍是内部自报，8倍是代码产量 |
| S03 | [Running an AI-native engineering org](https://claude.com/blog/running-an-ai-native-engineering-org)，Fiona Fung，2026-06-03 | 即时规划和按专业风险审查；不是取消全部规格或责任 |
| S04 | [Building effective agents](https://www.anthropic.com/engineering/building-effective-agents)，2024-12-19 | 简单可组合模式与workflow/agent区别；原文提示具体工具已变化 |
| S05 | [Effective context engineering for AI agents](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents)，2025-09-29 | 最小上下文、压缩及结构化记录；摘要不替代当前事实 |
| S06 | [Writing effective tools for agents — with agents](https://www.anthropic.com/engineering/writing-tools-for-agents)，2025-09-11 | 工具用途、命名、有效返回和留出评测；不鼓励一接口一工具无限增加 |
| S07 | [Equipping agents for the real world with Agent Skills](https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills)，2025-10-16 | 渐进加载、脚本与参考资料；第三方Skill须审查 |
| S08 | [Effective harnesses for long-running agents](https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents)，2025-11-26 | 小步实现、检查点、真实功能验证；示例文件与Git操作不是通用授权 |
| S09 | [Harness design for long-running application development](https://www.anthropic.com/engineering/harness-design-long-running-apps)，Prithvi Rajasekaran，2026-03-24 | 生成与评估分离、实际交互验收及删除过时Harness；实验案例不是所有模型规律 |
| S10 | [Demystifying evals for AI agents](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents)，2026-01-09 | 最终环境状态、隔离试验、分层评分、pass@k/pass^k；不能用一次试用推断稳定性 |
| S11 | [Quantifying infrastructure noise in agentic coding evals](https://www.anthropic.com/engineering/infrastructure-noise)，2026-02-05 | 环境资源会改变评测；相同题目并不自动代表同条件对照 |
| S12 | [How we built our multi-agent research system](https://www.anthropic.com/engineering/multi-agent-research-system)，2025-06-13 | 明确分工、并行成本与协调局限；研究领域结果不能直接套到代码协作 |
| S13 | [Making Claude Code more secure and autonomous with sandboxing](https://www.anthropic.com/engineering/claude-code-sandboxing)，2025-10-20 | 文件与网络边界组合；存在文章不代表当前机器已隔离 |
| S14 | [Zero Trust for AI agents](https://claude.com/blog/zero-trust-for-ai-agents)，2026-05-27 | 面向任务的身份/访问/记忆风险；此处核对网页概要，未把所链白皮书全文列为已读 |
| S15 | [Extend Claude with skills](https://code.claude.com/docs/en/skills)，动态文档 | 个人/项目发现和名称优先级；需实际宿主验证 |
| S16 | [Hooks reference](https://code.claude.com/docs/en/hooks)，动态文档 | 事件、退出码、JSON和超时行为不同；hook不能一概等于硬权限 |
| S17 | [anthropics/skills](https://github.com/anthropics/skills)，滚动仓库 | 官方Skill结构与分目录许可区别；没有下载执行或复制仓库代码 |

工程索引 https://www.anthropic.com/engineering 用于发现文章，不作为实现证据。曾尝试按标题推测基础设施文章URL未成功，已用搜索定位S11正式地址；没有将失败地址列作来源。第三方中文转述仅作为研究起点，关键结论均回到上述一手材料。
