# 生命周期参考入口

六阶段、任务依赖及恢复以 [workflow.md](workflow.md) 为当前规则；项目适配以 [project-adapters.md](project-adapters.md) 为准，风险与实际授权见 [security-review.md](security-review.md)。保留此入口供此前引用接续，不维护第二份生命周期规则。
