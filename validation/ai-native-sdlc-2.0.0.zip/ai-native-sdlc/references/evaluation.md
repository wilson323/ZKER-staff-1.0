# 证据校验辅助工具

行为回放、工具回归、同条件比较和指标以 [evidence-evals.md](evidence-evals.md) 为准。本页只补充可选证据工具；已有项目报告优先复用。

按 `assets/evidence-template.json` 填真实工具结果，运行 `python3 <Skill目录>/scripts/verify_evidence.py --root <项目绝对根> --receipt <项目内相对JSON路径>`。此脚本只验证记录完整性，不执行声明命令或认证作者。

字段：带时区的started_at/finished_at；project_root为实际绝对根；scope为DOCUMENTS/STATIC/BUILD/INTEGRATION/BUSINESS/RECOVERY/SKILL_TOOLS之一。inputs/artifacts每项含相对path与sha256；checks每项含id、真实argv、整数exit_code、正整数assertions、log的path/sha256、simulated标记。真实系统范围另填runtime_provenance。空模板、空日志、零断言、模拟业务与变更文件不能通过。

原始日志来自真实执行，不得为了满足字段制造成功。工具不会识别语义正确性，文件哈希不是签名。日志不得包含凭据或私人内容。
