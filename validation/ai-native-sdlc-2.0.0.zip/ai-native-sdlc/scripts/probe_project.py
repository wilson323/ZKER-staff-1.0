#!/usr/bin/env python3
"""Read bounded project markers. No writes, network, subprocesses or script execution."""
import argparse
import hashlib
import json
from pathlib import Path

MAX_BYTES = 524288
MARKERS = (
    'AGENTS.md', 'CLAUDE.md', 'README.md', 'CONTEXT.md', 'REVIEW.md',
    'Makefile', 'pyproject.toml', 'requirements.txt', 'setup.cfg',
    'package.json', 'package-lock.json', 'pnpm-lock.yaml', 'yarn.lock',
    'pom.xml', 'build.gradle', 'build.gradle.kts', 'go.mod', 'Cargo.toml',
    '.planning/STATE.md', 'task-graph.yaml',
    'validation/development-workflow.json', 'docs/plan.md',
)


def probe(root_arg):
    given = Path(root_arg)
    if not given.is_absolute():
        raise ValueError('an explicit absolute project root is required')
    root = given.resolve(strict=True)
    if not root.is_dir():
        raise ValueError('project root must be a directory')
    markers, skipped, contents = [], [], {}
    for relative in MARKERS:
        candidate = root / relative
        # Refuse symlink components, including dangling links and parent directory links.
        chain = [root.joinpath(*Path(relative).parts[:i])
                 for i in range(1, len(Path(relative).parts) + 1)]
        if any(p.is_symlink() for p in chain):
            skipped.append({'path': relative, 'reason': 'symlink'})
            continue
        if not candidate.is_file():
            continue
        try:
            with candidate.open('rb') as stream:
                data = stream.read(MAX_BYTES + 1)
        except OSError:
            skipped.append({'path': relative, 'reason': 'unreadable'})
            continue
        if len(data) > MAX_BYTES:
            skipped.append({'path': relative, 'reason': 'oversize'})
            continue
        markers.append({'path': relative, 'sha256': hashlib.sha256(data).hexdigest()})
        if relative == 'package.json':
            contents[relative] = data
    present = {x['path'] for x in markers}
    stacks = []
    for name, files in (
        ('python', {'pyproject.toml', 'requirements.txt', 'setup.cfg'}),
        ('node', {'package.json'}), ('java', {'pom.xml', 'build.gradle', 'build.gradle.kts'}),
        ('go', {'go.mod'}), ('rust', {'Cargo.toml'}),
    ):
        if files & present:
            stacks.append(name)
    candidates = []
    if 'package.json' in contents:
        try:
            package = json.loads(contents['package.json'])
            scripts = package.get('scripts', {}) if isinstance(package, dict) else {}
            if not isinstance(scripts, dict):
                raise ValueError('scripts must be an object')
            for key in ('test', 'lint', 'typecheck', 'build', 'verify'):
                if isinstance(scripts.get(key), str) and scripts[key].strip():
                    candidates.append({'source': 'package.json', 'scriptName': key,
                                       'status': 'DECLARED_NOT_REVIEWED_OR_RUN'})
        except (ValueError, UnicodeDecodeError):
            skipped.append({'path': 'package.json', 'reason': 'invalid package metadata'})
    return {
        'scope': 'READ_ONLY_PROJECT_HINTS', 'root': str(root),
        'status': 'HINTS_ONLY' if markers else 'UNKNOWN',
        'stackHints': stacks, 'markers': markers, 'skipped': skipped,
        'workflowCandidates': sorted(present & {
            '.planning/STATE.md', 'task-graph.yaml', 'validation/development-workflow.json', 'docs/plan.md'}),
        'verificationCandidates': candidates,
        'checksExecuted': [], 'productReady': False,
        'limitations': ['Markers are not verified commands or authoritative state.',
                       'No parent directory, source tree, secret or service scan.',
                       'Not a security sandbox; concurrent hostile filesystem changes are not contained.'],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    args = parser.parse_args()
    try:
        result = probe(args.root)
    except (ValueError, OSError) as error:
        print(json.dumps({'status': 'ERROR', 'error': str(error), 'checksExecuted': []}))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
