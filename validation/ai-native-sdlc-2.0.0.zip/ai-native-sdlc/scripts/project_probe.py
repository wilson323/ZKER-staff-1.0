"""Compatibility entrypoint; canonical discovery lives in probe_project.py."""
from pathlib import Path
import importlib.util

_spec = importlib.util.spec_from_file_location('sdlc_canonical_probe', Path(__file__).with_name('probe_project.py'))
_impl = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_impl)
probe = _impl.probe

if __name__ == '__main__':
    raise SystemExit(_impl.main())
