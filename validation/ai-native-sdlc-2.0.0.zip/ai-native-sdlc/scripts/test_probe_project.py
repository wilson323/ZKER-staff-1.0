import json
from pathlib import Path
import tempfile
import unittest
from probe_project import probe, MAX_BYTES


class ProbeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()

    def write(self, name, text):
        p = self.root / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
        return p

    def test_requires_absolute_root(self):
        with self.assertRaises(ValueError):
            probe('.')

    def test_missing_root(self):
        with self.assertRaises(OSError):
            probe(str(self.root / 'missing'))

    def test_file_root(self):
        with self.assertRaises(ValueError):
            probe(str(self.write('README.md', 'x')))

    def test_empty_not_ready(self):
        result = probe(str(self.root))
        self.assertEqual(result['status'], 'UNKNOWN')
        self.assertFalse(result['productReady'])
        self.assertEqual(result['checksExecuted'], [])

    def test_python_marker(self):
        self.write('pyproject.toml', '[project]\nname="sample"')
        self.assertEqual(probe(str(self.root))['stackHints'], ['python'])

    def test_node_scripts_not_executed(self):
        self.write('package.json', json.dumps({'scripts': {'test': 'touch sentinel', 'deploy': 'false'}}))
        result = probe(str(self.root))
        self.assertEqual([x['scriptName'] for x in result['verificationCandidates']], ['test'])
        self.assertFalse((self.root / 'sentinel').exists())
        self.assertEqual(result['checksExecuted'], [])

    def test_mixed_stacks(self):
        self.write('pom.xml', '<project/>')
        self.write('package.json', '{}')
        self.assertEqual(probe(str(self.root))['stackHints'], ['node', 'java'])

    def test_bad_package_shape(self):
        self.write('package.json', '{"scripts": 42}')
        self.assertEqual(probe(str(self.root))['skipped'][0]['reason'], 'invalid package metadata')

    def test_bad_package_encoding(self):
        (self.root / 'package.json').write_bytes(b'\xff')
        self.assertEqual(probe(str(self.root))['verificationCandidates'], [])

    def test_preserves_workflow(self):
        p = self.write('.planning/STATE.md', 'current=TASK-7')
        before = p.read_bytes()
        result = probe(str(self.root))
        self.assertEqual(result['workflowCandidates'], ['.planning/STATE.md'])
        self.assertEqual(p.read_bytes(), before)

    def test_no_parent_inference(self):
        self.write('pom.xml', '<project/>')
        child = self.root / 'child'
        child.mkdir()
        self.assertEqual(probe(str(child))['stackHints'], [])

    def test_secrets_not_read_or_printed(self):
        self.write('.env', 'SECRET_SENTINEL')
        self.assertNotIn('SECRET_SENTINEL', json.dumps(probe(str(self.root))))
        self.assertEqual(probe(str(self.root))['markers'], [])

    def test_symlink_file_skipped(self):
        p = self.write('secret', 'PRIVATE_SENTINEL')
        (self.root / 'README.md').symlink_to(p)
        result = probe(str(self.root))
        self.assertEqual(result['markers'], [])
        self.assertEqual(result['skipped'][0]['reason'], 'symlink')

    def test_symlink_directory_skipped(self):
        self.write('external/STATE.md', 'PRIVATE_SENTINEL')
        (self.root / '.planning').symlink_to(self.root / 'external', target_is_directory=True)
        self.assertEqual(probe(str(self.root))['workflowCandidates'], [])

    def test_large_marker_skipped(self):
        self.write('README.md', 'a' * (MAX_BYTES + 1))
        self.assertEqual(probe(str(self.root))['skipped'][0]['reason'], 'oversize')

    def test_changed_input_hash(self):
        self.write('README.md', 'before')
        before = probe(str(self.root))['markers']
        self.write('README.md', 'after')
        self.assertNotEqual(probe(str(self.root))['markers'], before)


if __name__ == '__main__':
    unittest.main()
