# 一手来源导航

唯一机器可读来源目录为 [sources.json](sources.json)，全文研究与S01—S16分析见 [research.md](research.md)。沿用该目录的S编号，避免多个编号体系指向不同文章。2026-09-11共核对20项来源：16篇文章正文、1个官方介绍页、2份动态文档、1个官方仓库。目录与网页摘要不是额外独立证据。

补充来源：

- S17 [Running an AI-native engineering org](https://claude.com/blog/running-an-ai-native-engineering-org)，2026-06-03：即时规划与专业风险审查。代码产量不能替代价值。
- S18 [Extend Claude with skills](https://code.claude.com/docs/en/skills)，2026-09-11核对：个人/项目加载与同名优先级。发现文件不等于宿主自动加载实测。
- S19 [Hooks reference](https://code.claude.com/docs/en/hooks)，2026-09-11核对：退出码、事件与超时语义需分别处理。非零退出不普遍代表阻断。
- S20 [anthropics/skills](https://github.com/anthropics/skills)，2026-09-11核对：部分文档Skill是source-available，不能按根目录印象当成全部开源。未下载执行仓库代码。

其余核心原文包括产物链、上下文、工具、长期Harness、评测、隔离与身份。官方内部数字仅用于描述其经验，不是跨项目效果承诺。Zero Trust链接白皮书全文未核对；只使用介绍页所支持的结论。本文模板和脚本为工程适配，没有引用未知第三方脚本作为实现。
