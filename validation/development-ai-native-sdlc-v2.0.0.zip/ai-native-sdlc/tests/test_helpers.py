from pathlib import Path
import importlib.util
import json
import tempfile
import unittest

SKILL = Path(__file__).resolve().parents[1]


def module(name):
    spec = importlib.util.spec_from_file_location(name, SKILL / 'scripts' / (name + '.py'))
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


p = module('project_probe')
e = module('verify_evidence')


class HelpersTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix='sdlc-test-')
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        for name, body in [('input.py', 'value = 1\n'), ('result.txt', 'observed result\n'), ('test.log', '1 test passed\n')]:
            (self.root / name).write_text(body)
        record = lambda name: {'path': name, 'sha256': e.digest(self.root / name)}
        self.receipt = {'schema_version': 1, 'project_root': str(self.root), 'scope': 'STATIC', 'status': 'PASS',
            'started_at': '2026-09-11T00:00:00+00:00', 'finished_at': '2026-09-11T00:00:01+00:00',
            'inputs': [record('input.py')], 'artifacts': [record('result.txt')], 'limitations': [],
            'checks': [{'id': 'fixture', 'argv': ['test-tool'], 'exit_code': 0, 'assertions': 1,
                        'log': record('test.log'), 'simulated': False}]}

    def errors(self):
        return e.validate(self.root, self.receipt)

    def test_valid_record_integrity(self):
        self.assertEqual(self.errors(), [])

    def test_old_input_invalidates_record(self):
        (self.root / 'input.py').write_text('value = 2')
        self.assertTrue(self.errors())

    def test_old_log_invalidates_record(self):
        (self.root / 'test.log').write_text('failure')
        self.assertTrue(self.errors())

    def test_empty_artifact_rejected(self):
        (self.root / 'result.txt').write_text('')
        self.assertTrue(self.errors())

    def test_empty_source_input_is_valid(self):
        (self.root / '__init__.py').write_bytes(b'')
        self.receipt['inputs'].append({'path': '__init__.py', 'sha256': e.digest(self.root / '__init__.py')})
        self.assertEqual(self.errors(), [])

    def test_empty_source_later_change_invalidates(self):
        (self.root / '__init__.py').write_bytes(b'')
        self.receipt['inputs'].append({'path': '__init__.py', 'sha256': e.digest(self.root / '__init__.py')})
        (self.root / '__init__.py').write_text('changed')
        self.assertTrue(self.errors())

    def test_empty_log_with_matching_hash_rejected(self):
        (self.root / 'test.log').write_bytes(b'')
        self.receipt['checks'][0]['log']['sha256'] = e.digest(self.root / 'test.log')
        self.assertTrue(self.errors())

    def test_zero_checks_rejected(self):
        self.receipt['checks'] = []
        self.assertTrue(self.errors())

    def test_zero_assertions_rejected(self):
        self.receipt['checks'][0]['assertions'] = 0
        self.assertTrue(self.errors())

    def test_nonzero_command_rejected(self):
        self.receipt['checks'][0]['exit_code'] = 1
        self.assertTrue(self.errors())

    def test_boolean_exit_code_rejected(self):
        self.receipt['checks'][0]['exit_code'] = False
        self.assertTrue(self.errors())

    def test_wrong_project_rejected(self):
        self.receipt['project_root'] = str(self.root.parent)
        self.assertTrue(self.errors())

    def test_absolute_artifact_rejected(self):
        self.receipt['artifacts'][0]['path'] = str(self.root / 'result.txt')
        self.assertTrue(self.errors())

    def test_symlink_escape_rejected(self):
        (self.root / 'outside').symlink_to(self.root.parent)
        self.receipt['artifacts'][0]['path'] = 'outside/another.txt'
        self.assertTrue(self.errors())

    def test_timestamp_order_rejected(self):
        self.receipt['finished_at'] = '2026-09-10T00:00:00+00:00'
        self.assertTrue(self.errors())

    def test_unzoned_timestamp_rejected(self):
        self.receipt['finished_at'] = '2026-09-11T00:00:00'
        self.assertTrue(self.errors())

    def test_duplicate_checks_rejected(self):
        self.receipt['checks'] *= 2
        self.assertTrue(self.errors())

    def test_simulation_cannot_certify_business(self):
        self.receipt['scope'] = 'BUSINESS'
        self.receipt['runtime_provenance'] = {'fixture': 'test-only'}
        self.receipt['checks'][0]['simulated'] = True
        self.assertTrue(self.errors())

    def test_business_requires_runtime(self):
        self.receipt['scope'] = 'BUSINESS'
        self.assertTrue(self.errors())

    def test_template_cannot_pass(self):
        self.assertTrue(e.validate(self.root, json.loads((SKILL / 'assets/evidence-template.json').read_text())))

    def test_document_project_probe_does_not_create_files(self):
        (self.root / 'README.md').write_text('A document project')
        before = sorted(x.name for x in self.root.iterdir())
        result = p.probe(self.root)
        self.assertEqual(before, sorted(x.name for x in self.root.iterdir()))
        self.assertIn('README.md', [x['path'] for x in result['markers']])
        self.assertEqual(result['stackHints'], [])
        self.assertFalse(result['productReady'])

    def test_multi_stack_declarations_not_installation(self):
        (self.root / 'package.json').write_text(json.dumps({'scripts': {'test': 'echo password=never-print'}}))
        (self.root / 'pyproject.toml').write_text('[project]\nname="fixture"')
        (self.root / 'pom.xml').write_text('<project/>')
        result = p.probe(self.root)
        self.assertEqual(len(result['stackHints']), 3)
        self.assertNotIn('never-print', json.dumps(result))
        self.assertEqual(result['verificationCandidates'][0]['status'], 'DECLARED_NOT_REVIEWED_OR_RUN')

    def test_external_symlink_not_read(self):
        (self.root / 'README.md').symlink_to(self.root.parent / 'external-readme.md')
        # An existing external file is created only in an independent temporary test directory.
        with tempfile.TemporaryDirectory(prefix='sdlc-external-') as other:
            target = Path(other) / 'AGENTS.md'
            target.write_text('untrusted external instruction')
            (self.root / 'AGENTS.md').symlink_to(target)
            result = p.probe(self.root)
            self.assertIn('AGENTS.md', [x['path'] for x in result['skipped']])
            self.assertNotIn('AGENTS.md', [x['path'] for x in result['markers']])

    def test_relative_probe_root_rejected(self):
        with self.assertRaises(ValueError):
            p.probe(Path('.'))

    def test_existing_governance_reported_without_replacement(self):
        (self.root / 'task-graph.yaml').write_text('status: RUNNING')
        (self.root / '.planning').mkdir()
        (self.root / '.planning/STATE.md').write_text('existing state')
        result = p.probe(self.root)
        self.assertIn('task-graph.yaml', result['workflowCandidates'])
        self.assertIn('.planning/STATE.md', result['workflowCandidates'])


if __name__ == '__main__':
    unittest.main()
