"""Validate recorded local evidence; does not execute commands or certify business truth."""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import json
import re


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resolve_local(root, value):
    if not isinstance(value, str) or not value or Path(value).is_absolute():
        raise ValueError('artifact paths must be relative to this project')
    path = (root / value).resolve()
    if not path.is_relative_to(root):
        raise ValueError('artifact points outside this project')
    return path


def validate(root, receipt):
    errors = []
    if not isinstance(receipt, dict):
        return ['receipt must be an object']
    if receipt.get('schema_version') != 1 or receipt.get('status') != 'PASS':
        errors.append('receipt is not a completed version-1 PASS record')
    if receipt.get('scope') not in {'DOCUMENTS', 'STATIC', 'BUILD', 'INTEGRATION', 'BUSINESS', 'RECOVERY', 'SKILL_TOOLS'}:
        errors.append('explicit supported verification scope required')
    if not isinstance(receipt.get('project_root'), str) or not receipt['project_root']:
        errors.append('project_root required')
    elif Path(receipt['project_root']).resolve() != root:
        errors.append('project root mismatch; another project receipt cannot be reused')
    try:
        started = datetime.fromisoformat(receipt['started_at'])
        finished = datetime.fromisoformat(receipt['finished_at'])
        if not started.tzinfo or not finished.tzinfo or finished < started:
            errors.append('invalid or unzoned execution timestamps')
    except (KeyError, ValueError, TypeError):
        errors.append('execution start and finish timestamps required')
    for group in ['inputs', 'checks', 'artifacts']:
        if not isinstance(receipt.get(group), list) or not receipt[group]:
            errors.append(f'non-empty {group} required; zero checks cannot pass')
    if errors:
        return errors

    def artifact(item, label):
        try:
            path = resolve_local(root, item['path'])
            if not path.is_file() or (label != 'inputs' and path.stat().st_size == 0):
                errors.append(f'{label}: file missing or empty')
            elif not re.fullmatch('[0-9a-f]{64}', item.get('sha256', '')) or digest(path) != item['sha256']:
                errors.append(f'{label}: content changed or invalid hash')
        except (KeyError, TypeError, ValueError, OSError) as e:
            errors.append(f'{label}: {e}')

    for group in ('inputs', 'artifacts'):
        for item in receipt[group]:
            artifact(item, group)
    ids = []
    for check in receipt['checks']:
        if not isinstance(check, dict):
            errors.append('check must be an object')
            continue
        ids.append(check.get('id'))
        if (not check.get('id') or not isinstance(check.get('argv'), list) or not check['argv']
                or any(not isinstance(v, str) or not v for v in check['argv'])
                or type(check.get('exit_code')) is not int or check['exit_code'] != 0):
            errors.append('check needs ID, argv and real successful exit code')
        if type(check.get('assertions')) is not int or check['assertions'] <= 0:
            errors.append('positive observed assertion count required')
        artifact(check.get('log', {}), 'check log')
        if check.get('simulated') is not False and receipt['scope'] in {'INTEGRATION', 'BUSINESS', 'RECOVERY'}:
            errors.append('simulated result cannot certify real-system scope')
    if len(ids) != len(set(ids)):
        errors.append('duplicate check IDs')
    if receipt['scope'] in {'INTEGRATION', 'BUSINESS', 'RECOVERY'} and not receipt.get('runtime_provenance'):
        errors.append('real-system scope needs runtime provenance')
    if not isinstance(receipt.get('limitations'), list):
        errors.append('limitations must be explicit, possibly empty')
    return errors


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--receipt', required=True)
    args = parser.parse_args()
    try:
        if not args.root.is_absolute() or not args.root.is_dir():
            raise ValueError('root must be an existing absolute directory')
        root = args.root.resolve()
        receipt = json.loads(resolve_local(root, args.receipt).read_text())
        errors = validate(root, receipt)
        print(json.dumps({'status': 'FAIL' if errors else 'PASS', 'errors': errors,
                          'scope': 'RECORDED_EVIDENCE_INTEGRITY_ONLY', 'business_certified': False}, ensure_ascii=False))
        raise SystemExit(1 if errors else 0)
    except (OSError, ValueError, TypeError) as e:
        parser.exit(2, f'EVIDENCE_ERROR: {e}\n')
