import test from 'node:test';
import assert from 'node:assert/strict';
import {buildQuery} from '../lib/query.js';
test('keeps zero',()=>assert.equal(buildQuery({page:0}),'page=0'));

test('keeps false and empty strings while omitting null and undefined', () => {
  assert.equal(buildQuery({flag: false, query: '', absent: null, missing: undefined}), 'flag=false&query=');
});

test('encodes keys and values with URLSearchParams semantics', () => {
  assert.equal(buildQuery({'q &': 'a+b=c/中', punctuation: "~!*'()", space: 'a b'}),
    'q+%26=a%2Bb%3Dc%2F%E4%B8%AD&punctuation=%7E%21*%27%28%29&space=a+b');
});

test('preserves object and array order using repeated keys', () => {
  assert.equal(buildQuery({before: 'first', tag: ['z', null, 0, undefined, false, '', 'a'], after: 'last'}),
    'before=first&tag=z&tag=0&tag=false&tag=&tag=a&after=last');
});

test('returns an empty query when there are no retained values', () => {
  assert.equal(buildQuery({}), '');
  assert.equal(buildQuery({empty: [], absent: null, missing: undefined, tags: [null, undefined]}), '');
});

test('does not mutate the input object or array', () => {
  const tags = Object.freeze(['z', null, 0, undefined, false, '', 'a']);
  const values = Object.freeze({before: 'first', tag: tags, after: 'last'});
  const snapshot = structuredClone(values);
  assert.equal(buildQuery(values), 'before=first&tag=z&tag=0&tag=false&tag=&tag=a&after=last');
  assert.deepEqual(values, snapshot);
  assert.equal(values.tag, tags);
});
