# Query builder
Node standard library; no packages required. Run: node --test
Task authority: .planning/STATE.md, task Q-12.
