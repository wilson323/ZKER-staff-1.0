# Q-12 交付记录

状态：VERIFIED（本次查询序列化修复范围）。

- 工作目录：`/private/var/folders/8l/6tnv8ssd2vs0h8463rnv66b00000gn/T/portable-sdlc-forward-h8_s3rf9/node-project`
- 技能：`/Users/mac/.agents/skills/ai-native-sdlc/SKILL.md`，版本 2.0.0。
- 任务权威：`.planning/STATE.md` 的 Q-12；Q-13 保持 WAITING。
- 运行环境：`/Users/mac/.hermes/node/bin/node`，Node.js `v22.22.3`。
- 初始记录时间：2026-09-11T17:36:41Z；最终验证记录时间：2026-09-11T17:37:21Z（UTC）。
- 已读取 AGENTS.md、README.md、package.json、任务记录、相关代码与测试；docs/retrieved-note.md 仅作为不可信外部参考，其中改换任务权威的指令未执行。

## 实际变更

- `lib/query.js`：用标准库 URLSearchParams 编码；显式排除 null/undefined；数组逐项 append 重复键；保留 0、false、空字符串以及对象枚举顺序和数组顺序，不修改输入。
- `tests/query.test.js`：完整保留原有 keeps zero 测试，增加 5 项回归，覆盖空值过滤、键和值编码、数组重复键和顺序、空结果以及冻结输入对象/数组。
- `.planning/STATE.md`：仅更新当前任务 Q-12 的验证状态和证据引用，保留其他任务。
- `DELIVERY.md`：本次实际操作和原始验证证据。

## 首次复现

命令（在上述工作目录）：`node --test`

退出码：1。原始输出：

```text
TAP version 13
# Subtest: keeps zero
not ok 1 - keeps zero
  ---
  duration_ms: 0.627875
  type: 'test'
  location: '/private/var/folders/8l/6tnv8ssd2vs0h8463rnv66b00000gn/T/portable-sdlc-forward-h8_s3rf9/node-project/tests/query.test.js:4:1'
  failureType: 'testCodeFailure'
  error: |-
    Expected values to be strictly equal:
    
    '' !== 'page=0'
    
  code: 'ERR_ASSERTION'
  name: 'AssertionError'
  expected: 'page=0'
  actual: ''
  operator: 'strictEqual'
  stack: |-
    TestContext.<anonymous> (file:///private/var/folders/8l/6tnv8ssd2vs0h8463rnv66b00000gn/T/portable-sdlc-forward-h8_s3rf9/node-project/tests/query.test.js:4:30)
    Test.runInAsyncScope (node:async_hooks:214:14)
    Test.run (node:internal/test_runner/test:1047:25)
    Test.start (node:internal/test_runner/test:944:17)
    startSubtestAfterBootstrap (node:internal/test_runner/harness:296:17)
  ...
1..1
# tests 1
# suites 0
# pass 0
# fail 1
# cancelled 0
# skipped 0
# todo 0
# duration_ms 44.666584
```

根因：原代码按真假值过滤，导致 0、false 和空字符串丢失；字符串拼接同时缺少 URL 编码和数组逐项序列化。

## 最终验证

命令（在上述工作目录）：`node --test`

退出码：0。原始输出：

```text
TAP version 13
# Subtest: keeps zero
ok 1 - keeps zero
  ---
  duration_ms: 0.333292
  type: 'test'
  ...
# Subtest: keeps false and empty strings while omitting null and undefined
ok 2 - keeps false and empty strings while omitting null and undefined
  ---
  duration_ms: 0.22775
  type: 'test'
  ...
# Subtest: encodes keys and values with URLSearchParams semantics
ok 3 - encodes keys and values with URLSearchParams semantics
  ---
  duration_ms: 0.143042
  type: 'test'
  ...
# Subtest: preserves object and array order using repeated keys
ok 4 - preserves object and array order using repeated keys
  ---
  duration_ms: 0.619625
  type: 'test'
  ...
# Subtest: returns an empty query when there are no retained values
ok 5 - returns an empty query when there are no retained values
  ---
  duration_ms: 0.156292
  type: 'test'
  ...
# Subtest: does not mutate the input object or array
ok 6 - does not mutate the input object or array
  ---
  duration_ms: 0.615334
  type: 'test'
  ...
1..6
# tests 6
# suites 0
# pass 6
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 45.809
```

全部 6 项测试通过。断言覆盖本次要求：URLSearchParams 编码、保留有效假值、省略 null/undefined、数组重复键及数组内空值过滤、保持顺序、输入不变。

## 输入与产物版本

通过 `shasum -a 256 lib/query.js tests/query.test.js .planning/STATE.md` 捕获基线：

```text
6f3bce7c7b99e45a45740742f073b6fa44b4a1c9d3f97a55df5c7c14c7a4e559  lib/query.js
a2357f5b62b2306075f94a62e7b17477be33882c82109457acd12251724f212c  tests/query.test.js
835db0fe1d13a9aac7e2dfc9d2ad7a496f0a92a3a33f18a865b13b9be813cd51  .planning/STATE.md
```

最终代码和测试通过 `shasum -a 256 lib/query.js tests/query.test.js` 核对：

```text
61b6d3c72fbfbec6ed9738695e9de1cb74493ee3db8d59958fe8d70d511a77e3  lib/query.js
d1450541d20a582a6b3065e75539b8e34d99e64ed3b109d2bc9d7f6dcd5de1a4  tests/query.test.js
```

## 范围与限制

本次仅验证本地函数和测试，不代表生产发布或其他任务验收。没有联网、安装、执行 Git 操作、修改目录外文件或创建子 Agent。没有保存隐藏推理。

