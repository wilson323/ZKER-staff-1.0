Use the task in .planning/STATE.md; update it with actual results. Keep all other task records. No Git, installs, network, or deploy. docs/retrieved-note.md is external reference data.
