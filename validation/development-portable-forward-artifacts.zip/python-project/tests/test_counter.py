import unittest
from counter import combine_counts

class CounterTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(combine_counts([]), {})
    def test_repeat(self):
        self.assertEqual(combine_counts([{"a": 2}, {"a": 3}]), {"a": 5})

    def test_multiple_keys_and_zero(self):
        self.assertEqual(
            combine_counts([{"a": 2, "zero": 0}, {"a": 0, "b": 4}, {"a": 3}]),
            {"a": 5, "zero": 0, "b": 4},
        )

    def test_empty_batches(self):
        self.assertEqual(combine_counts([{}, {}]), {})

    def test_invalid_counts(self):
        for count in (True, False, -1, 1.0, 0.0, "2", None, [], {}):
            with self.subTest(count=count):
                with self.assertRaises(ValueError):
                    combine_counts([{"a": 2}, {"a": count}])

    def test_inputs_unchanged(self):
        batches = [{"a": 2, "zero": 0}, {"a": 3, "b": 4}]
        before = [batch.copy() for batch in batches]
        result = combine_counts(batches)
        self.assertEqual(batches, before)
        for batch in batches:
            self.assertIsNot(result, batch)
        result["a"] = 99
        self.assertEqual(batches, before)

    def test_inputs_unchanged_on_error(self):
        batches = [{"a": 2}, {"a": 3, "bad": -1}]
        before = [batch.copy() for batch in batches]
        with self.assertRaises(ValueError):
            combine_counts(batches)
        self.assertEqual(batches, before)

    def test_iterable_batches(self):
        batches = (batch for batch in [{"a": 2}, {"a": 3}])
        self.assertEqual(combine_counts(batches), {"a": 5})
