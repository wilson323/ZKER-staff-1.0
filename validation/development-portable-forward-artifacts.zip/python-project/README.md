# Batch counter
Python standard library only. Check: python3 -m unittest discover -s tests -v
