def combine_counts(batches):
    result = {}
    for batch in batches:
        for key, count in batch.items():
            if isinstance(count, bool) or not isinstance(count, int) or count < 0:
                raise ValueError("Counts must be non-negative integers")
            result[key] = result.get(key, 0) + count
    return result
