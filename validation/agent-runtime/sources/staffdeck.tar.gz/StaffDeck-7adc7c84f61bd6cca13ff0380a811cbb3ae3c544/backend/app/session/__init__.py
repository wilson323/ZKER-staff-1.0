"""Session schemas and helpers."""

