---
name: ai-native-sdlc
description: Apply Anthropic's AI-Native SDLC playbook to a real codebase — Plan → Design → Build → Test → Deploy → Maintain with versioned artifacts (intent.md / spec.md / plan.md), deterministic controls (CLAUDE.md + Skills + Hooks), four-layer governance (guidance / execution / evidence / responsibility), and the human-in-the-loop gates the playbook expects. Use when the user wants to start a feature as intent.md, convert intent to spec.md under policy, write plan.md before code, set up CLAUDE.md + Skills + Hooks for the repo, decide what an agent is allowed to do in production without per-action approval, compose a self-verifying make-verify, run agent Evals after config changes, or close a production alert back into a triage intent. Triggers on phrases like "AI-Native SDLC", "intent.md / spec.md / plan.md", "plan mode for this", "what should I gate vs auto in prod", "production deploy policy", "Skills and Hooks for this repo", "make this PR agent-friendly", "close the maintenance loop".
---

# ai-native-sdlc

Anthropic's *AI-Native SDLC playbook* (blog, 2026-08-21) reframes software delivery as a closed loop of versioned artifacts: `intent.md` → `spec.md` → `plan.md` → code/tests/PR → production telemetry → back into `intent.md`. Code is no longer the bottleneck; the new bottleneck is the system that surrounds the agent.

This file is the working form. Reach for the branch you are on; the rest is reference.

## Operating principles (apply to every branch)

Five leading words do most of the work:

- **artifacts** — every plan, spec, test, and PR description is a file in the repo, not a chat line.
- **policy** — the org's rules go in as Skills, not as guidance paragraphs.
- **evidence** — "it works" is checked (`make verify`, Evals, screenshots), not asserted.
- **gates** — the agent can stop at a boundary; humans cross the high-risk one.
- **loop** — production writes the next intent, every merge is mid-cycle.

A rule is **soft** when it can ride as guidance (Skills, CLAUDE.md). It is **hard** when only a deterministic control can hold it (command hook, sandbox, permission, CI gate). Drag a soft rule into a hard control and you over-spend tokens; leave a hard rule on a Skill and the agent will eventually slip. Match the layer to the load.

## The six stages

Read only the stage the user is on.

### Plan — `intent.md`

Trigger: a real problem worth version-controlling, not a chat-only request.

1. Ask five questions: problem, who it affects, success looks like, hard limits, unknowns.
2. Draft `intent.md` with sections Problem / Users / Outcome / Target systems / Hard limits / Open questions.
3. One round of clarification, then stop designing.
4. A human (product owner or equivalent) accepts it; only then move on.

Completion criterion: `intent.md` exists, no TBD in Problem/Users/Outcome, and a named reviewer has accepted it.

If a Jira/Linear/ServiceNow ticket already exists, extract intent into `intent.md` and link both ways. Tickets get archived; the artifact lives in the repo's history.

### Design — `spec.md` under policy

Trigger: `intent.md` accepted.

1. Generate `spec.md` against the relevant Skills (security, brand, compliance, UX) and the repo's CLAUDE.md.
2. Inline-flag conflicts and risks; do not paper over them.
3. Three reviewers: product (does spec solve intent?), policy owner (do flagged risks hold?), tech lead only on high-risk items.
4. Acceptance moves the artifact into Build.

Completion criterion: every intent question is resolved or explicitly escalated; three reviewer names logged.

### Build — `plan.md` first, then code with self-evidence

Trigger: `spec.md` accepted.

1. Enter plan mode. Read `intent.md`, `spec.md`, the codebase, CLAUDE.md, and the relevant Skills.
2. Write `plan.md` that names files to change, order, highest-risk step, what existing behaviour might break, the tests that prove the change, and the alternatives you rejected.
3. An engineer / architect corrects the plan before any code. Editing a plan is a paper move; code on a wrong plan is wasted work.
4. Code only after plan approval. If implementation drifts, update `plan.md` in the same commit.

Completion criterion: `plan.md` and the final diff agree on file list, order, and tests.

The three supporting pieces work together:

- **CLAUDE.md** at the repo root holds codebase-wide knowledge: build commands, directory responsibilities, conventions, and the corrections for mistakes the agent has already made twice. Keep it tight; staleness eats context.
- **Skills** hold rules that must stay stable across many tasks (security standards, API conventions, brand rules). Each Skill has a trigger condition and a named policy owner. Agents load them on demand.
- **Hooks** run at fixed points in the agent's lifecycle. Command-style hooks give deterministic guarantees (block writes to generated dirs, refuse to read secrets, format after edit). Prompt-style hooks are model-judged and fit semantic checks. For hard production boundaries, lean on command hooks, permissions, sandboxes, or CI gates — not prompt hooks.

Skills raise the probability the agent follows a rule; deterministic controls hold the line.

### Test — every change proves itself

Trigger: code written, bug fixed, or agent config changed.

1. Compose one command (`make verify`) that runs tests, lint, type, build, snapshot, screenshots.
2. The agent runs it before claiming done and includes the output in the report.
3. For bug fixes: write a failing test that reproduces, confirm it fails for the right reason, commit the test, then change the implementation. The agent must not edit the test as part of the fix.
4. Run **Evals** when agent config changes (model, prompt, CLAUDE.md, Skill, Hook). 20–50 historical tasks give the signal; every production incident adds a regression case.

Completion criterion: `make verify` is green in the agent's reported run; bug-fix tests fail before the fix and pass after.

Software tests answer "does the code work?" Agent Evals answer "does this agent config still meet our standard?" Keep both.

### Deploy — agent reaches the gate, does not cross it

Trigger: PR opened or production release planned.

1. **PR review**: a reviewer agent applies a single policy (logic errors, security, spec/plan adherence). Findings are severity-sorted. For agent-opened PRs, the agent iterates on review comments, fixes the branch, re-runs checks, and stops at Code Owner signoff.
2. **Release gates**: a PreToolUse hook (or the platform equivalent) sits in front of deploy actions. Each action is **allow / ask / refuse**. Repo-wide rules live in the org-managed config (e.g. `.claude/settings.json`); only that layer holds policy no individual can switch off.
3. **Production authorization** stays with a named human. Protected paths need a change ticket. Sensitive secrets and network access live behind a sandbox.

Completion criterion: deployment went through a defined gate, the named human signed, and the deploy record is auditable.

This is the separation of duties: the writer does not approve; humans own residual risk. The human reviewer's job shifts from "scan for typos" to "judge intent, blast radius, residual risk."

### Maintain — production writes the next intent

Trigger: a deterministic monitor alerts, or a recurring cron fires.

1. Deterministic monitors detect stable signals (post-release 5xx, CI failure rate, PR cycle time). When a signal crosses its control band, an agent diagnoses.
2. Diagnosis is written as `intent.md` (the same shape as the planning artifact) and routed back through spec → plan → build → test → review.

Completion criterion: the diagnosis was committed as a versioned artifact and followed the same chain as a normal change.

Keep **detection** deterministic and **explanation** model-driven. Each layer should have its own confidence gate (a deterministic check or an adversarial reviewer agent) before any action. Low confidence escalates to a human.

Autonomy by environment:
- **Dev** — highest autonomy: CI failure diagnosis, changelog drafts, test-flake analysis.
- **Staging** — a step tighter.
- **Production** — human authorization stays.

Match autonomy to environment, not to enthusiasm.

## Four-layer control stack (reference)

Use this table to decide where a rule belongs.

| Layer                | Mechanism                             | Job                                       | Type            |
|----------------------|---------------------------------------|-------------------------------------------|-----------------|
| Guidance             | Prompt, CLAUDE.md, Skills             | how the agent should work                 | advice          |
| Deterministic exec   | command Hooks, permissions, sandbox   | what the agent is allowed to do           | hard boundary   |
| Verification & evidence | tests, Evals, screenshots, logs   | proves results match expectations         | auditable       |
| Responsibility & approval | Code Owner, risk owner, release manager | human signs for the high-risk call    | accountability  |

The layers do not substitute for each other: a Skill can be skipped by a confused agent; a command hook holds regardless of model behaviour; tests prove covered cases but cannot decide whether residual risk is acceptable; humans sign only when the other three layers produce honest evidence.

A better maturity bar than "agent runs for X hours": are the boundaries explicit, is verification automated, do failures roll back, do approvals trace, do low-confidence cases escalate?

## Human role — a few high-value gates

Putting a human in the loop on every step makes humans the bottleneck again and gives them nothing to do.

Concentrate humans on:
- intent acceptance (is the problem captured?)
- spec acceptance (does it solve intent?)
- plan and tech risk
- behaviour and blast radius
- production authorization
- low-confidence or anomalous results

Mechanical checks go to tests, Evals, hooks, and reviewer agents. Decisions about intent, trade-offs, and responsibility stay human.

This also caps concurrency. One engineer can supervise several agent sessions in parallel; the cap is the number they can review well, not the number the agent can start.

## Roll-out path (reference)

Each step stands on its own; you can stop after any step.

1. **Self-evidence for one agent** — wire `make verify`, write a tight CLAUDE.md, require the agent to run verify before claiming done. Goal: raise first-pass CI rate.
2. **intent → spec → plan artifact chain** — pick one bounded, low-risk project; define templates, owners, accept actions, and where the authoritative record lives. If you use Jira/ServiceNow, keep them as the ID source but mirror to Markdown; both sides carry the other ID to avoid silent drift.
3. **Policy into machine-enforceable controls** — pick one frequently-broken rule with an owner: write it as a Skill, encode the boundary as a command hook or CI check, add the broken-by-history case to Evals. Then layer PR review and Code Owner approval.
4. **Phased autonomy** — start CI with read-only tasks (failure diagnosis, changelog drafts, test flakiness). Then let agents open PR fixes. Production-triggered unattended loops only after permissions, sandbox, gating, and rollback all hold.

Leading vs lagging signal per stage:

| Stage     | Leading                                              | Lagging                                  |
|-----------|------------------------------------------------------|------------------------------------------|
| Plan      | time to first intent.md                              | intent acceptance, late rework           |
| Build     | first-pass impl pass rate, plan→merge time          | rework rounds, plan/diff drift           |
| Test      | agent CI first-pass rate                             | prod regression, change failure rate     |
| Review    | first-review duration, auto-resolved comment share   | escaped defects, escaped vulns           |
| Maintain  | auto-diagnosis coverage, escalation rate             | MTTR, repeat incidents                   |

If code speed rises and change failure rate, rework, and alert volume rise with it, the system is producing bad output faster.

## Boundaries of the playbook

Vendor practice guide. The core ideas (artifact chains, deterministic gates, environment tiers, continuous Evals) are platform-agnostic. The concrete mechanisms (Skills, Hooks, the Anthropic CLI) need mapping to your tooling.

It does not ship controlled-experiment productivity numbers. Targets like "weeks to hours" are hypotheses; validate against your own Git / CI / PR / incident data.

The hard part is usually org-chart-shaped: who accepts `intent.md`; does the policy owner maintain the Skill; will security accept machine-generated evidence; how this fits existing change management. None of that is solved by an agent install.

Closed-loop automation magnifies misconfiguration. One wrong rule, one noisy signal, one incomplete Eval is repeated at every stage. Version control, independent gates, observability, and rollback are prerequisites, not follow-ons.

## Source attribution (read when the user asks "is this just a gloss on the title?")

This skill is a working distillation of Anthropic's *The AI-Native SDLC playbook* (blog, 2026-08-21) plus the implementation write-ups, critiques, and open-source clones that landed in the same August 2026 window. Read these for the canonical wording and operational depth; this file is the muscle-memory form.

Primary:
- The playbook (original): https://claude.com/blog/the-ai-native-sdlc-playbook
- Security companion: https://claude.com/blog/how-anthropic-secures-its-ai-native-software-development-lifecycle
- Org adoption companion: https://claude.com/blog/running-an-ai-native-engineering-org
- Skills / Hooks / Subagents deep dive: https://claude.com/ko/blog/steering-claude-code-skills-hooks-rules-subagents-and-more
- Production deploy patterns: https://claude.com/blog/auto-mode-in-production

中文权威解读（2026-08 当月窗口内）:
- 智源 BAAI: https://hub.baai.ac.cn/view/57492
- 腾讯云开发者（含五层治理控制栈版）: https://cloud.tencent.com.cn/developer/article/2731319
- 安全内参: https://www.secrss.com/articles/92668
- AI Native 方法论转载: https://api.aitntnews.com/newDetail.html?newId=28629

实操 / 批评 / 实现:
- Port.io 落地指南: https://www.port.io/blog/anthropic-ai-native-sdlc-playbook
- Waydev 批评（缺失度量层）: https://waydev.co/anthropics-ai-native-sdlc-playbook-has-a-missing-layer-measurement
- GitHub 可复用 skill/plugin: https://github.com/bashebr/ai-native-sdlc
- Agentic SDLC pipeline 实现: https://github.com/kyisaiah47/agentic-sdlc
- 实践者笔记: https://dev.to/helderberto/how-i-use-claude-code-to-build-features-4lbe

行业影响:
- VentureBeat: https://venturebeat.com/ai/claude-code-turned-every-engineer-into-three-now-companies-need-more-product-thinkers
- Cocoloop 概述: https://news.cocoloop.cn/en/2026/08/anthropic-ai-native-sdlc-playbook/
- PLAN vs SPEC 比较: https://github.com/sanmak/specops/blob/main/docs/PLAN-VS-SPEC.md
